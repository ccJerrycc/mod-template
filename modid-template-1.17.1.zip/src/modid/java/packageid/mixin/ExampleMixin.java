package packageid.mixin;

import Example;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(Example.class)
public class ExampleMixin {
}